The attached schematic was based on several breakout products I used to prototype the connections, and start the software.

The attached board file was an attempt to route this. As this was my first eagle project I do not know enough to accomplish the routing. The file has expected board dimensions, as well as required pin place ment for an Arduino shield, and desired pin locations for external connections.  All other components can be arranged as desired. I tried to closely follow the example board. Arduino pin connections are firm.

I am not overly concerned about being in spec for the full amperage of the device. This is for a prototype, So trace widths as used in the board file should be ok as long as large pads are used to attach the 2 X 33926.

I need a board file ready to process in eagle, to send to manufacturing.  I used spark fun DRU before and had no problem having a much simpler arduino shield board made.

Hopefully, someone who knows what they are doing with eagle routing, this is a fast easy job. Any questions feel free to ask, via the elance preferred communications, or by direct email, spiked3@gmail.com


Thanks,
Mike